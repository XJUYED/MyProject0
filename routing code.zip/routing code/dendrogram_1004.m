clear all;
close all;
clc;
xBS=500;                                   %%%%%% ������վ������
yBS=500;                                   %%%%%% ������վ������
scatter(xBS,yBS,'bo','linewidth',4);
hold on
load ('C:\Users\YED\Desktop\routing code\C_L_H_BS_Bianhao_Zuobiao_1004.mat');
long_L_1004=length(C_L_Zuobiao_x_1004);
C_L_Zuobiao_1004=[C_L_Zuobiao_x_1004' C_L_Zuobiao_y_1004'];
C_H_Zuobiao_1004=[xH' yH'];
C_L_H_Zuobiao_1004=[C_L_Zuobiao_1004;C_H_Zuobiao_1004];
C_H_BS_Zuobiao_1004=[xH_BS' yH_BS'];
C_L_H_BS_x_1004=C_L_H_BS_Bianhao_Zuobiao_1004(2,:);
C_L_H_BS_y_1004=C_L_H_BS_Bianhao_Zuobiao_1004(3,:);
C_L_H_BS_Zuobiao_1004=[C_L_H_BS_x_1004;C_L_H_BS_y_1004]';
long_L_H_BS_1004=length(C_L_H_BS_Zuobiao_1004);
%%%%%%%%1004���ڽڵ��ͨ����·�ж�
for i=1:long_L_1004
   text(C_L_Zuobiao_x_1004(i),C_L_Zuobiao_y_1004(i),num2str(i,'%d'));
end
scatter(C_L_Zuobiao_x_1004,C_L_Zuobiao_y_1004,'b.');
hold on

long_H_BS_1004=length(xH_BS);
for j=1:long_H_BS_1004
    text(xH_BS(j),yH_BS(j),num2str(j+long_L_1004,'%d'));
end
scatter(xH_BS,yH_BS,'r*');
hold on
%%% L�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
for i_L_1004=1:long_L_1004
     bb = [C_L_Zuobiao_1004(i_L_1004,1) C_L_Zuobiao_1004(i_L_1004,2)];
      for j_L_1004= 1:long_L_1004
      cc = [C_L_Zuobiao_1004(j_L_1004,1) C_L_Zuobiao_1004(j_L_1004,2)];
          A(i_L_1004,j_L_1004) = norm(bb - cc);
      end
 end
 A(find(A>60))=inf;
 %% H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
 long_H_1004=length(C_H_Zuobiao_1004);
for i_H_1004=1:long_H_1004
      ee = [C_H_Zuobiao_1004(i_H_1004,1) C_H_Zuobiao_1004(i_H_1004,2)];
for j_L_1004=1:long_L_1004
      ff = [C_L_Zuobiao_1004(j_L_1004,1) C_L_Zuobiao_1004(j_L_1004,2)];
         B(i_H_1004,j_L_1004) = norm(ee-ff);
end
end
B(find(B>150))=inf;
%%H�ڵ���H�ڵ�֮��ͨ�ŷ�Χ 
 for i_H_1004=1:long_H_1004
     gg = [C_H_Zuobiao_1004(i_H_1004,1) C_H_Zuobiao_1004(i_H_1004,2)];
     for j_H_1004=1:long_H_1004
     hh = [C_H_Zuobiao_1004(j_H_1004,1) C_H_Zuobiao_1004(j_H_1004,2)];
     C(i_H_1004,j_H_1004) = norm(gg - hh);
     end
 end
C(find(C>300))=inf;
D=[A,B';B,C]; 
% s =input('�������'); % ��㣨�����ţ�
% e =input('�����յ�'); % �յ㣨�����ţ�
%%%%%%%���1004������ͨ�ڵ����·��
e_H_1004=long_L_1004+(1004-1000);
length(C_L_H_BS_Zuobiao_1004(:,1));
part_L_1004={};
for s_L_1004=1:long_L_1004
[d_L_1004, p_L_1004, pred_L_1004] = graphshortestpath(sparse(D), s_L_1004, e_H_1004);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_L_1004);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_L_1004);
part_L_1004=[part_L_1004;{p_L_1004}];
for i = 1:size(p_L_1004,2)-1
    line([C_L_H_Zuobiao_1004(p_L_1004(i),1) C_L_H_Zuobiao_1004(p_L_1004(i+1),1)],[C_L_H_Zuobiao_1004(p_L_1004(i),2) C_L_H_Zuobiao_1004(p_L_1004(i+1),2)]);
end
end
%%%%%%���1004�ؼ�H�ڵ㵽BS���·��
 %% BS/H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
long_H_BS_1004=length(C_H_BS_Zuobiao_1004);
for i_H_BS_1004=1:long_H_BS_1004
      mm = [C_H_BS_Zuobiao_1004(i_H_BS_1004,1) C_H_BS_Zuobiao_1004(i_H_BS_1004,2)];
for j_L_1004=1:long_L_1004
      nn = [C_L_Zuobiao_1004(j_L_1004,1) C_L_Zuobiao_1004(j_L_1004,2)];
      E(i_H_BS_1004,j_L_1004) = norm(mm-nn);
end
end
 E(find(E>150))=inf;
 %%BS/H�ڵ���H�ڵ�֮��ͨ�ŷ�Χ 
long_H_BS_1004=length(C_H_BS_Zuobiao_1004);
 for i_H_BS_1004=1:long_H_BS_1004
     uu = [C_H_BS_Zuobiao_1004(i_H_BS_1004,1) C_H_BS_Zuobiao_1004(i_H_BS_1004,2)];
     for j_H_BS_1004=1:long_H_BS_1004
     vv = [C_H_BS_Zuobiao_1004(j_H_BS_1004,1) C_H_BS_Zuobiao_1004(j_H_BS_1004,2)];
     F(i_H_BS_1004,j_H_BS_1004) = norm(uu - vv);
     end
 end
F(find(F>300))=inf;
G=[A,E';E,F]; 
ss_H_1004=e_H_1004;
BS_1004=length(C_L_H_BS_Zuobiao_1004);
% BS_Bianhao=text(Base_x,Base_y,num2str(BS_1004,'%d'));
[d_H_1004, p_H_1004, pred_H_1004] = graphshortestpath(sparse(G),ss_H_1004, BS_1004);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_H_1004);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_H_1004);
for i = 1:size(p_H_1004,2)-1
    line([C_L_H_BS_Zuobiao_1004(p_H_1004(i),1) C_L_H_BS_Zuobiao_1004(p_H_1004(i+1),1)],[C_L_H_BS_Zuobiao_1004(p_H_1004(i),2) C_L_H_BS_Zuobiao_1004(p_H_1004(i+1),2)]);
end
