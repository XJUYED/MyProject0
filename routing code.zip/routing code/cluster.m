function [Xu_L_H_BS]=cluster(hang_L,hang_H_BS)
Na=21;
Nb=1000; 
c=[];
d=[];
% num=0;
num_L=[];
% HnumL=[];

for i=1:Na
    count=0;
    for j=1:Nb
        if hang_H_BS(j) ==i
            c=[c,hang_L(j)]; 
            count=count+1;
        end
    end
    num_L=[num_L,count];
   
end

for k=1:Na
    L_H_BS(k,:)=zeros(1,max(num_L));
    if k==1
        L_H_BS(k,:)=[c(1:num_L(k)),zeros(1,max(num_L)-num_L(1))];
    else
        L_H_BS(k,:)=[c(sum(num_L((1:k-1)))+1:sum(num_L((1:k)))),zeros(1,max(num_L)-num_L(k))];
    end
end
   

Xu_L_H_BS=[[1:Na]',L_H_BS];



    