clc;
close all;
clear all;
M=20;
n=196;
H=[];
y1=[];
y2=[];
y3=[];
y4=[];
L=[];
x=[];
Original_Centralized_ECC=[];
Original_Distributed_ECC=[];
Wang_Distributed_ECC=[];
our_scheme=[];
for i=4:4:M
    H=[H,i];
end
for j=1:5
        t=n*j;
        L=[L,t];
end
for k=1:5
    r1= (H(k)+2)*L(k)+3*H(k);
    y1=[y1,r1];
    r2=3*H(k)+2*L(k);
    y2=[y2,r2];
    r3=3*H(k)+2*L(k);
    y3=[y3,r3];
    r4=3*H(k)+2*L(k);
    y4=[y4,r4];
end
for s=200:200:1000
    x=[x,s];
end
plot(x,y1,'-ob',x,y2,'-*r',x,y3,'-+k',x,y4,'-.g','LineWidth',1)
legend('Original Centralized Key Management Scheme','Original Distributed Key Management Scheme','Wang Proposed Scheme','Our Proposed Scheme');
xlabel('The number of nodes')
ylabel('Total storage space')

