clear all;
close all;
clc;
xBS=500;                                   %%%%%% ������վ������
yBS=500;                                   %%%%%% ������վ������
scatter(xBS,yBS,'bo','linewidth',4);
hold on
load ('C:\Users\YED\Desktop\routing code\C_L_H_BS_Bianhao_Zuobiao_1016.mat');
long_L_1016=length(C_L_Zuobiao_x_1016);
C_L_Zuobiao_1016=[C_L_Zuobiao_x_1016' C_L_Zuobiao_y_1016'];
C_H_Zuobiao_1016=[xH' yH'];
C_L_H_Zuobiao_1016=[C_L_Zuobiao_1016;C_H_Zuobiao_1016];
C_H_BS_Zuobiao_1016=[xH_BS' yH_BS'];
C_L_H_BS_x_1016=C_L_H_BS_Bianhao_Zuobiao_1016(2,:);
C_L_H_BS_y_1016=C_L_H_BS_Bianhao_Zuobiao_1016(3,:);
C_L_H_BS_Zuobiao_1016=[C_L_H_BS_x_1016;C_L_H_BS_y_1016]';
long_L_H_BS_1016=length(C_L_H_BS_Zuobiao_1016);
%%%%%%%%1016���ڽڵ��ͨ����·�ж�
for i=1:long_L_1016
   text(C_L_Zuobiao_x_1016(i),C_L_Zuobiao_y_1016(i),num2str(i,'%d'));
end
scatter(C_L_Zuobiao_x_1016,C_L_Zuobiao_y_1016,'b.');
hold on

long_H_BS_1016=length(xH_BS);
for j=1:long_H_BS_1016
    text(xH_BS(j),yH_BS(j),num2str(j+long_L_1016,'%d'));
end
scatter(xH_BS,yH_BS,'r*');
hold on
%%% L�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
for i_L_1016=1:long_L_1016
     bb = [C_L_Zuobiao_1016(i_L_1016,1) C_L_Zuobiao_1016(i_L_1016,2)];
      for j_L_1016= 1:long_L_1016
      cc = [C_L_Zuobiao_1016(j_L_1016,1) C_L_Zuobiao_1016(j_L_1016,2)];
          A(i_L_1016,j_L_1016) = norm(bb - cc);
      end
 end
 A(find(A>60))=inf;
 %% H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
 long_H_1016=length(C_H_Zuobiao_1016);
for i_H_1016=1:long_H_1016
      ee = [C_H_Zuobiao_1016(i_H_1016,1) C_H_Zuobiao_1016(i_H_1016,2)];
for j_L_1016=1:long_L_1016
      ff = [C_L_Zuobiao_1016(j_L_1016,1) C_L_Zuobiao_1016(j_L_1016,2)];
         B(i_H_1016,j_L_1016) = norm(ee-ff);
end
end
B(find(B>150))=inf;
%%H�ڵ���H�ڵ�֮��ͨ�ŷ�Χ 
 for i_H_1016=1:long_H_1016
     gg = [C_H_Zuobiao_1016(i_H_1016,1) C_H_Zuobiao_1016(i_H_1016,2)];
     for j_H_1016=1:long_H_1016
     hh = [C_H_Zuobiao_1016(j_H_1016,1) C_H_Zuobiao_1016(j_H_1016,2)];
     C(i_H_1016,j_H_1016) = norm(gg - hh);
     end
 end
C(find(C>300))=inf;
D=[A,B';B,C]; 
% s =input('�������'); % ��㣨�����ţ�
% e =input('�����յ�'); % �յ㣨�����ţ�
%%%%%%%���1016������ͨ�ڵ����·��
e_H_1016=long_L_1016+(1016-1000);
length(C_L_H_BS_Zuobiao_1016(:,1));
part_L_1016={};
for s_L_1016=1:long_L_1016
[d_L_1016, p_L_1016, pred_L_1016] = graphshortestpath(sparse(D), s_L_1016, e_H_1016);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_L_1016);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_L_1016);
part_L_1016=[part_L_1016;{p_L_1016}];
for i = 1:size(p_L_1016,2)-1
    line([C_L_H_Zuobiao_1016(p_L_1016(i),1) C_L_H_Zuobiao_1016(p_L_1016(i+1),1)],[C_L_H_Zuobiao_1016(p_L_1016(i),2) C_L_H_Zuobiao_1016(p_L_1016(i+1),2)]);
end
end
%%%%%%���1016�ؼ�H�ڵ㵽BS���·��
 %% BS/H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
long_H_BS_1016=length(C_H_BS_Zuobiao_1016);
for i_H_BS_1016=1:long_H_BS_1016
      mm = [C_H_BS_Zuobiao_1016(i_H_BS_1016,1) C_H_BS_Zuobiao_1016(i_H_BS_1016,2)];
for j_L_1016=1:long_L_1016
      nn = [C_L_Zuobiao_1016(j_L_1016,1) C_L_Zuobiao_1016(j_L_1016,2)];
      E(i_H_BS_1016,j_L_1016) = norm(mm-nn);
end
end
 E(find(E>150))=inf;
 %%BS/H�ڵ���H�ڵ�֮��ͨ�ŷ�Χ 
long_H_BS_1016=length(C_H_BS_Zuobiao_1016);
 for i_H_BS_1016=1:long_H_BS_1016
     uu = [C_H_BS_Zuobiao_1016(i_H_BS_1016,1) C_H_BS_Zuobiao_1016(i_H_BS_1016,2)];
     for j_H_BS_1016=1:long_H_BS_1016
     vv = [C_H_BS_Zuobiao_1016(j_H_BS_1016,1) C_H_BS_Zuobiao_1016(j_H_BS_1016,2)];
     F(i_H_BS_1016,j_H_BS_1016) = norm(uu - vv);
     end
 end
F(find(F>300))=inf;
G=[A,E';E,F]; 
ss_H_1016=e_H_1016;
BS_1016=length(C_L_H_BS_Zuobiao_1016);
% BS_Bianhao=text(Base_x,Base_y,num2str(BS_1016,'%d'));
[d_H_1016, p_H_1016, pred_H_1016] = graphshortestpath(sparse(G),ss_H_1016, BS_1016);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_H_1016);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_H_1016);
for i = 1:size(p_H_1016,2)-1
    line([C_L_H_BS_Zuobiao_1016(p_H_1016(i),1) C_L_H_BS_Zuobiao_1016(p_H_1016(i+1),1)],[C_L_H_BS_Zuobiao_1016(p_H_1016(i),2) C_L_H_BS_Zuobiao_1016(p_H_1016(i+1),2)]);
end
