clear all;
close all;
clc;
xBS=500;                                   %%%%%% ������վ������
yBS=500;                                   %%%%%% ������վ������
scatter(xBS,yBS,'bo','linewidth',4);
hold on
load ('C:\Users\YED\Desktop\routing code\C_L_H_BS_Bianhao_Zuobiao_1020.mat');
long_L_1020=length(C_L_Zuobiao_x_1020);
C_L_Zuobiao_1020=[C_L_Zuobiao_x_1020' C_L_Zuobiao_y_1020'];
C_H_Zuobiao_1020=[xH' yH'];
C_L_H_Zuobiao_1020=[C_L_Zuobiao_1020;C_H_Zuobiao_1020];
C_H_BS_Zuobiao_1020=[xH_BS' yH_BS'];
C_L_H_BS_x_1020=C_L_H_BS_Bianhao_Zuobiao_1020(2,:);
C_L_H_BS_y_1020=C_L_H_BS_Bianhao_Zuobiao_1020(3,:);
C_L_H_BS_Zuobiao_1020=[C_L_H_BS_x_1020;C_L_H_BS_y_1020]';
long_L_H_BS_1020=length(C_L_H_BS_Zuobiao_1020);
%%%%%%%%1020���ڽڵ��ͨ����·�ж�
for i=1:long_L_1020
   text(C_L_Zuobiao_x_1020(i),C_L_Zuobiao_y_1020(i),num2str(i,'%d'));
end
scatter(C_L_Zuobiao_x_1020,C_L_Zuobiao_y_1020,'b.');
hold on

long_H_BS_1020=length(xH_BS);
for j=1:long_H_BS_1020
    text(xH_BS(j),yH_BS(j),num2str(j+long_L_1020,'%d'));
end
scatter(xH_BS,yH_BS,'r*');
hold on
%%% L�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
for i_L_1020=1:long_L_1020
     bb = [C_L_Zuobiao_1020(i_L_1020,1) C_L_Zuobiao_1020(i_L_1020,2)];
      for j_L_1020= 1:long_L_1020
      cc = [C_L_Zuobiao_1020(j_L_1020,1) C_L_Zuobiao_1020(j_L_1020,2)];
          A(i_L_1020,j_L_1020) = norm(bb - cc);
      end
 end
 A(find(A>60))=inf;
 %% H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
 long_H_1020=length(C_H_Zuobiao_1020);
for i_H_1020=1:long_H_1020
      ee = [C_H_Zuobiao_1020(i_H_1020,1) C_H_Zuobiao_1020(i_H_1020,2)];
for j_L_1020=1:long_L_1020
      ff = [C_L_Zuobiao_1020(j_L_1020,1) C_L_Zuobiao_1020(j_L_1020,2)];
         B(i_H_1020,j_L_1020) = norm(ee-ff);
end
end
B(find(B>150))=inf;
%%H�ڵ���H�ڵ�֮��ͨ�ŷ�Χ 
 for i_H_1020=1:long_H_1020
     gg = [C_H_Zuobiao_1020(i_H_1020,1) C_H_Zuobiao_1020(i_H_1020,2)];
     for j_H_1020=1:long_H_1020
     hh = [C_H_Zuobiao_1020(j_H_1020,1) C_H_Zuobiao_1020(j_H_1020,2)];
     C(i_H_1020,j_H_1020) = norm(gg - hh);
     end
 end
C(find(C>300))=inf;
D=[A,B';B,C]; 
% s =input('�������'); % ��㣨�����ţ�
% e =input('�����յ�'); % �յ㣨�����ţ�
%%%%%%%���1020������ͨ�ڵ����·��
e_H_1020=long_L_1020+(1020-1000);
length(C_L_H_BS_Zuobiao_1020(:,1));
part_L_1020={};
for s_L_1020=1:long_L_1020
[d_L_1020, p_L_1020, pred_L_1020] = graphshortestpath(sparse(D), s_L_1020, e_H_1020);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_L_1020);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_L_1020);
part_L_1020=[part_L_1020;{p_L_1020}];
for i = 1:size(p_L_1020,2)-1
    line([C_L_H_Zuobiao_1020(p_L_1020(i),1) C_L_H_Zuobiao_1020(p_L_1020(i+1),1)],[C_L_H_Zuobiao_1020(p_L_1020(i),2) C_L_H_Zuobiao_1020(p_L_1020(i+1),2)]);
end
end
%%%%%%���1020�ؼ�H�ڵ㵽BS���·��
 %% BS/H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
long_H_BS_1020=length(C_H_BS_Zuobiao_1020);
for i_H_BS_1020=1:long_H_BS_1020
      mm = [C_H_BS_Zuobiao_1020(i_H_BS_1020,1) C_H_BS_Zuobiao_1020(i_H_BS_1020,2)];
for j_L_1020=1:long_L_1020
      nn = [C_L_Zuobiao_1020(j_L_1020,1) C_L_Zuobiao_1020(j_L_1020,2)];
      E(i_H_BS_1020,j_L_1020) = norm(mm-nn);
end
end
 E(find(E>150))=inf;
 %%BS/H�ڵ���H�ڵ�֮��ͨ�ŷ�Χ 
long_H_BS_1020=length(C_H_BS_Zuobiao_1020);
 for i_H_BS_1020=1:long_H_BS_1020
     uu = [C_H_BS_Zuobiao_1020(i_H_BS_1020,1) C_H_BS_Zuobiao_1020(i_H_BS_1020,2)];
     for j_H_BS_1020=1:long_H_BS_1020
     vv = [C_H_BS_Zuobiao_1020(j_H_BS_1020,1) C_H_BS_Zuobiao_1020(j_H_BS_1020,2)];
     F(i_H_BS_1020,j_H_BS_1020) = norm(uu - vv);
     end
 end
F(find(F>300))=inf;
G=[A,E';E,F]; 
ss_H_1020=e_H_1020;
BS_1020=length(C_L_H_BS_Zuobiao_1020);
% BS_Bianhao=text(Base_x,Base_y,num2str(BS_1020,'%d'));
[d_H_1020, p_H_1020, pred_H_1020] = graphshortestpath(sparse(G),ss_H_1020, BS_1020);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_H_1020);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_H_1020);
for i = 1:size(p_H_1020,2)-1
    line([C_L_H_BS_Zuobiao_1020(p_H_1020(i),1) C_L_H_BS_Zuobiao_1020(p_H_1020(i+1),1)],[C_L_H_BS_Zuobiao_1020(p_H_1020(i),2) C_L_H_BS_Zuobiao_1020(p_H_1020(i+1),2)]);
end
