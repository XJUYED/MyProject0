function [x,y]=scatter_H(ax0,yb0,xa,yb)
x=ax0+(xa-ax0).*rand();
y=yb0+(yb-yb0).*rand();
end

