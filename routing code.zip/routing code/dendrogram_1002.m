clear all;
close all;
clc;
xBS=500;                                   %%%%%% ������վ������
yBS=500;                                   %%%%%% ������վ������
scatter(xBS,yBS,'bo','linewidth',4);
hold on
load ('C:\Users\YED\Desktop\routing code\C_L_H_BS_Bianhao_Zuobiao_1002.mat');
long_L_1002=length(C_L_Zuobiao_x_1002);
C_L_Zuobiao_1002=[C_L_Zuobiao_x_1002' C_L_Zuobiao_y_1002'];
C_H_Zuobiao_1002=[xH' yH'];
C_L_H_Zuobiao_1002=[C_L_Zuobiao_1002;C_H_Zuobiao_1002];
C_H_BS_Zuobiao_1002=[xH_BS' yH_BS'];
C_L_H_BS_x_1002=C_L_H_BS_Bianhao_Zuobiao_1002(2,:);
C_L_H_BS_y_1002=C_L_H_BS_Bianhao_Zuobiao_1002(3,:);
C_L_H_BS_Zuobiao_1002=[C_L_H_BS_x_1002;C_L_H_BS_y_1002]';
long_L_H_BS_1002=length(C_L_H_BS_Zuobiao_1002);
%%%%%%%%1002���ڽڵ��ͨ����·�ж�
for i=1:long_L_1002
   text(C_L_Zuobiao_x_1002(i),C_L_Zuobiao_y_1002(i),num2str(i,'%d'));
end
scatter(C_L_Zuobiao_x_1002,C_L_Zuobiao_y_1002,'b.');
hold on

long_H_BS_1002=length(xH_BS);
for j=1:long_H_BS_1002
    text(xH_BS(j),yH_BS(j),num2str(j+long_L_1002,'%d'));
end
scatter(xH_BS,yH_BS,'r*');
hold on
%%% L�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
for i_L_1002=1:long_L_1002
     bb = [C_L_Zuobiao_1002(i_L_1002,1) C_L_Zuobiao_1002(i_L_1002,2)];
      for j_L_1002= 1:long_L_1002
      cc = [C_L_Zuobiao_1002(j_L_1002,1) C_L_Zuobiao_1002(j_L_1002,2)];
          A(i_L_1002,j_L_1002) = norm(bb - cc);
      end
 end
 A(find(A>60))=inf;
 %% H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
 long_H_1002=length(C_H_Zuobiao_1002);
for i_H_1002=1:long_H_1002
      ee = [C_H_Zuobiao_1002(i_H_1002,1) C_H_Zuobiao_1002(i_H_1002,2)];
for j_L_1002=1:long_L_1002
      ff = [C_L_Zuobiao_1002(j_L_1002,1) C_L_Zuobiao_1002(j_L_1002,2)];
         B(i_H_1002,j_L_1002) = norm(ee-ff);
end
end
B(find(B>150))=inf;
%%H�ڵ���H�ڵ�֮��ͨ�ŷ�Χ 
 for i_H_1002=1:long_H_1002
     gg = [C_H_Zuobiao_1002(i_H_1002,1) C_H_Zuobiao_1002(i_H_1002,2)];
     for j_H_1002=1:long_H_1002
     hh = [C_H_Zuobiao_1002(j_H_1002,1) C_H_Zuobiao_1002(j_H_1002,2)];
     C(i_H_1002,j_H_1002) = norm(gg - hh);
     end
 end
C(find(C>300))=inf;
D=[A,B';B,C]; 
% s =input('�������'); % ��㣨�����ţ�
% e =input('�����յ�'); % �յ㣨�����ţ�
%%%%%%%���1002������ͨ�ڵ����·��
e_H_1002=long_L_1002+(1002-1000);
length(C_L_H_BS_Zuobiao_1002(:,1));
part_L_1002={};
for s_L_1002=1:long_L_1002
[d_L_1002, p_L_1002, pred_L_1002] = graphshortestpath(sparse(D), s_L_1002, e_H_1002);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_L_1002);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_L_1002);
part_L_1002=[part_L_1002;{p_L_1002}];
for i = 1:size(p_L_1002,2)-1
    line([C_L_H_Zuobiao_1002(p_L_1002(i),1) C_L_H_Zuobiao_1002(p_L_1002(i+1),1)],[C_L_H_Zuobiao_1002(p_L_1002(i),2) C_L_H_Zuobiao_1002(p_L_1002(i+1),2)]);
end
end
%%%%%%���1002�ؼ�H�ڵ㵽BS���·��
 %% BS/H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
long_H_BS_1002=length(C_H_BS_Zuobiao_1002);
for i_H_BS_1002=1:long_H_BS_1002
      mm = [C_H_BS_Zuobiao_1002(i_H_BS_1002,1) C_H_BS_Zuobiao_1002(i_H_BS_1002,2)];
for j_L_1002=1:long_L_1002
      nn = [C_L_Zuobiao_1002(j_L_1002,1) C_L_Zuobiao_1002(j_L_1002,2)];
      E(i_H_BS_1002,j_L_1002) = norm(mm-nn);
end
end
 E(find(E>150))=inf;
 %%BS/H�ڵ���H�ڵ�֮��ͨ�ŷ�Χ 
long_H_BS_1002=length(C_H_BS_Zuobiao_1002);
 for i_H_BS_1002=1:long_H_BS_1002
     uu = [C_H_BS_Zuobiao_1002(i_H_BS_1002,1) C_H_BS_Zuobiao_1002(i_H_BS_1002,2)];
     for j_H_BS_1002=1:long_H_BS_1002
     vv = [C_H_BS_Zuobiao_1002(j_H_BS_1002,1) C_H_BS_Zuobiao_1002(j_H_BS_1002,2)];
     F(i_H_BS_1002,j_H_BS_1002) = norm(uu - vv);
     end
 end
F(find(F>300))=inf;
G=[A,E';E,F]; 
ss_H_1002=e_H_1002;
BS_1002=length(C_L_H_BS_Zuobiao_1002);
% BS_Bianhao=text(Base_x,Base_y,num2str(BS_1002,'%d'));
[d_H_1002, p_H_1002, pred_H_1002] = graphshortestpath(sparse(G),ss_H_1002, BS_1002);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_H_1002);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_H_1002);
for i = 1:size(p_H_1002,2)-1
    line([C_L_H_BS_Zuobiao_1002(p_H_1002(i),1) C_L_H_BS_Zuobiao_1002(p_H_1002(i+1),1)],[C_L_H_BS_Zuobiao_1002(p_H_1002(i),2) C_L_H_BS_Zuobiao_1002(p_H_1002(i+1),2)]);
end