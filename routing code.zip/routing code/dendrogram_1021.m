clear all;
close all;
clc;
xBS=500;                                   %%%%%% ������վ������
yBS=500;                                   %%%%%% ������վ������
scatter(xBS,yBS,'bo','linewidth',4);
hold on
load ('C:\Users\YED\Desktop\routing code\C_L_H_BS_Bianhao_Zuobiao_1021.mat');
long_L_1021=length(C_L_Zuobiao_x_1021);
C_L_Zuobiao_1021=[C_L_Zuobiao_x_1021' C_L_Zuobiao_y_1021'];
C_H_Zuobiao_1021=[xH' yH'];
C_L_H_Zuobiao_1021=[C_L_Zuobiao_1021;C_H_Zuobiao_1021];
C_H_BS_Zuobiao_1021=[xH_BS' yH_BS'];
C_L_H_BS_x_1021=C_L_H_BS_Bianhao_Zuobiao_1021(2,:);
C_L_H_BS_y_1021=C_L_H_BS_Bianhao_Zuobiao_1021(3,:);
C_L_H_BS_Zuobiao_1021=[C_L_H_BS_x_1021;C_L_H_BS_y_1021]';
long_L_H_BS_1021=length(C_L_H_BS_Zuobiao_1021);
%%%%%%%%1021���ڽڵ��ͨ����·�ж�
for i=1:long_L_1021
   text(C_L_Zuobiao_x_1021(i),C_L_Zuobiao_y_1021(i),num2str(i,'%d'));
end
scatter(C_L_Zuobiao_x_1021,C_L_Zuobiao_y_1021,'b.');
hold on

long_H_BS_1021=length(xH_BS);
for j=1:long_H_BS_1021
    text(xH_BS(j),yH_BS(j),num2str(j+long_L_1021,'%d'));
end
scatter(xH_BS,yH_BS,'r*');
hold on
%%% L�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
for i_L_1021=1:long_L_1021
     bb = [C_L_Zuobiao_1021(i_L_1021,1) C_L_Zuobiao_1021(i_L_1021,2)];
      for j_L_1021= 1:long_L_1021
      cc = [C_L_Zuobiao_1021(j_L_1021,1) C_L_Zuobiao_1021(j_L_1021,2)];
          A(i_L_1021,j_L_1021) = norm(bb - cc);
      end
 end
 A(find(A>60))=inf;
%% BS/H�ڵ���L�ڵ�֮��ͨ�ŷ�Χ
long_H_BS_1021=length(C_H_BS_Zuobiao_1021);
for i_H_BS_1021=1:long_H_BS_1021
      mm = [C_H_BS_Zuobiao_1021(i_H_BS_1021,1) C_H_BS_Zuobiao_1021(i_H_BS_1021,2)];
for j_L_1021=1:long_L_1021
      nn = [C_L_Zuobiao_1021(j_L_1021,1) C_L_Zuobiao_1021(j_L_1021,2)];
      B(i_H_BS_1021,j_L_1021) = norm(mm-nn);
end
end
 B(find(B>150))=inf;
%% BS/H�ڵ���BS/H�ڵ�֮��ͨ�ŷ�Χ
long_H_BS_1021=length(C_H_BS_Zuobiao_1021);
for i_H_BS_1021=1:long_H_BS_1021
      mm = [C_H_BS_Zuobiao_1021(i_H_BS_1021,1) C_H_BS_Zuobiao_1021(i_H_BS_1021,2)];
for j_H_BS_1021=1:long_H_BS_1021
      nn = [C_H_BS_Zuobiao_1021(j_H_BS_1021,1) C_H_BS_Zuobiao_1021(j_H_BS_1021,2)];
      C(i_H_BS_1021,j_H_BS_1021) = norm(mm-nn);
end
end
 C(find(C>200))=inf;
D=[A,B';B,C]; 
% % s =input('�������'); % ��㣨�����ţ�
% % e =input('�����յ�'); % �յ㣨�����ţ�
% %%%%%%%���1021������ͨ�ڵ����·��
e_BS_1021=long_L_1021+21;
part_L_1021={};
for s_L_1021=1:long_L_1021
[d_L_1021, p_L_1021, pred_L_1021] = graphshortestpath(sparse(D), s_L_1021, e_BS_1021);
fprintf('\n Use graphshortestpath the Min Distance is: %.5f \n', d_L_1021);
fprintf('\n Use graphshortestpath the Min Distance path is: \n');
disp(p_L_1021);
part_L_1021=[part_L_1021;{p_L_1021}];
for i = 1:size(p_L_1021,2)-1
    line([C_L_H_BS_Zuobiao_1021(p_L_1021(i),1) C_L_H_BS_Zuobiao_1021(p_L_1021(i+1),1)],[C_L_H_BS_Zuobiao_1021(p_L_1021(i),2) C_L_H_BS_Zuobiao_1021(p_L_1021(i+1),2)]);
end
end
